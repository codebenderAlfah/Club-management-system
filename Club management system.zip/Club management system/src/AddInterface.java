public interface AddInterface {

    public void function();
}

public interface ProjectInterface {

    public void function();
}

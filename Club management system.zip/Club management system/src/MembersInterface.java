public interface MembersInterface {
    public void function();
}
